from HelpCardMaker import ui
reload(ui)

def init_panel():
    return ui.MainPanel()